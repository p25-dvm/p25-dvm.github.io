# MY_PROJECT Docs

Documentation site for MY_PROJECT, built with [MkDocs](https://www.mkdocs.org/) and the [Material theme](https://squidfunk.github.io/mkdocs-material/), styled with a custom hacker aesthetic.

## Local development

```bash
pip install mkdocs-material
mkdocs serve
```

Visit http://127.0.0.1:8000

## Deploy

Push to `main` — GitHub Actions handles the rest. The site deploys automatically to GitHub Pages via the `gh-pages` branch.

## Customize

- **Theme / colors**: `docs/stylesheets/hacker.css`
- **JS effects**: `docs/javascripts/hacker.js`
- **Site config**: `mkdocs.yml`
- **Content**: `docs/**/*.md`

Remember to replace all `<your-github-username>` and `<your-repo-name>` placeholders in `mkdocs.yml` with your actual values.
